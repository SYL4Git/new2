import '../css/Loading.css';

export default () => {
    return (
        <div className="LoadingWrap">
            <div className="LoadingLogo">Petdoc</div>
        </div>
    );
};