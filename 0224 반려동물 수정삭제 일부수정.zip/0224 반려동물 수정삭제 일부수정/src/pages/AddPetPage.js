import EditPets from '../component/EditPets'

const AddPetPage = () => {

    return (
        <div className="AddPetPage">
            <EditPets />
        </div>
    )
}

export default AddPetPage;