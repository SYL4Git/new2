import { createContext } from "react";

const RadioContext=createContext({})

export default RadioContext